menu = """
----------  BANCO  ----------
    [1] Depositar 
    [2] Sacar
    [3] Extrato
    [4] Sair
-----------------------------

Escolha uma opção: 

"""
saldo = 0
limite = 500
extrato = ""
numero_saques = 0
LIMITE_SAQUES = 3
                
while True:
    opcao = int(input(menu))
    
    if opcao == 1:
        deposito = float(input("Digite a quantidade que deseja depositar: "))
        if deposito > 0:    
            saldo += deposito
            extrato += (f"R$ {deposito:.2f} foram depositados\n")
            print(f"Você depositou R${deposito:.2f}!")
        
        else:
            print("Operação falhou! Valor inválido.")
            
    elif opcao == 2:
        saque = float(input("Digite o valor que deseja sacar: "))
        
        excedeu_saldo = saque > saldo
        excedeu_numero_saques = numero_saques >= LIMITE_SAQUES
        excedeu_limite = saque > limite
        
        if excedeu_saldo:   
            print("Não há saldo suficiente para realizar esse saque!")
        
        elif excedeu_numero_saques:             
            print("Saque negado! Você já atingiu o número máximo de saques diários.")
            
        elif excedeu_limite:
            print("Operação falhou! O valor máximo de saque é de R$500,00.")
            
        elif saque > 0:
            saldo -= saque
            extrato += (f"R$ {saque:.2f} foram sacados\n")
            print(f"Você sacou R${saque:.2f}!")
            numero_saques += 1
        
        else:
            print("O valor digitado é inválido!")
        
    elif opcao == 3:
        print("\n========== EXTRATO ==========")
        print("Não foram realizados movimentaçãoes." if not extrato else extrato)
        print(f"\n Saldo: R$ {saldo:.2f}")
        print("===============================")
        
    elif opcao == 4:
        print("Obrigado, volte sempre!")
        break
    
    else:
        print("Opção inválida")
    
